# Saalik
This repo contains the frontend architecture and design themes for the saalik org.

#Installation
```bash
npm i
npm run dev
```
*NOTE: If you face any issues, run `npm i --force`*

